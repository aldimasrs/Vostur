#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Volumes/MYSSD/Tools/flutter"
export "FLUTTER_APPLICATION_PATH=/Volumes/MYSSD/Code Crafts/Video Code/11.Flutter-Login-UI/flutter_login"
export "FLUTTER_TARGET=/Volumes/MYSSD/Code Crafts/Video Code/11.Flutter-Login-UI/flutter_login/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build/ios"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_DEFINES=flutter.inspector.structuredErrors%3Dtrue"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Volumes/MYSSD/Code Crafts/Video Code/11.Flutter-Login-UI/flutter_login/.dart_tool/package_config.json"
